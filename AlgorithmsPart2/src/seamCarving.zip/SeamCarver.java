import edu.princeton.cs.algs4.Picture;
import edu.princeton.cs.algs4.StdOut;

import java.awt.Color;
import java.util.ArrayList;

/**
 * Created by kyledorman on 12/6/15.
 */
public class SeamCarver {
    private Color[][] pixels;
    private double[][] energy;
    private int width;
    private int height;
    private boolean inverted = false;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture) {
        if (picture == null) {
            throw new NullPointerException("null picture.");
        }
        height = picture.height();
        width = picture.width();
        pixels = new Color[height][width];
        energy = new double[height][width];


        for (int h = 0; h < height; h++) {
            for (int w = 0; w < width; w++) {
                pixels[h][w] = picture.get(w, h);
            }
        }

        for (int h = 0; h < height; h++) {
            for (int w = 0; w < width; w++) {
                energy[h][w] = calculateEnergy(w, h);
            }
        }
    }

    // current picture
    public Picture picture() {
        if (inverted) invert();

        Picture newPicture = new Picture(width, height);
        for (int h = 0; h < height; h++) {
            for (int w = 0; w < width; w++) {
                newPicture.set(w, h, pixels[h][w]);
            }
        }
        return newPicture;
    }

    // width of current picture
    public int width() {
        return width;
    }

    // height of current picture
    public int height() {
        return height;
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        verifyPoint(x, y);
        if (!inverted) return energy[y][x];
        else return energy[x][y];
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {
        if (!inverted) invert();
        return findGeneralSeam();
    }

    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {
        if (inverted) invert();
        return findGeneralSeam();
    }

    private int[] findGeneralSeam() {
        boolean[][] marked = new boolean[height][width];
        Double[][] distTo = new Double[height][width];
        // inverted so we can return the whole row at the end
        int[][] nextPoint = new int[height][width];

        double minValue = Double.POSITIVE_INFINITY;
        int rowIndex = -1;

        for (int w = 0; w < width; w++) {
            dfs(0, w, marked, distTo, nextPoint);

            if (minValue > distTo[0][w]) {
                minValue = distTo[0][w];
                rowIndex = w;
            }
        }

        int[] result = new int[height];
        result[0] = rowIndex;
        for (int i = 0; i < height - 1; i++) {
            rowIndex = nextPoint[i][rowIndex];
            result[i + 1] = rowIndex;
        }

        return result;
    }

    private void dfs(int h, int w, boolean[][] marked, Double[][] distTo, int[][] nextPoint) {
        if (!marked[h][w]) {
            marked[h][w] = true;

            for (Point p : adj(h, w)) {
                dfs(p.getY(), p.getX(), marked, distTo, nextPoint);
            }

            double minDistTo = Double.POSITIVE_INFINITY;
            int next = -1;
            for (Point p : adj(h, w)) {
                double pointEnergy = distTo[p.getY()][p.getX()];
                if (minDistTo > pointEnergy) {
                    minDistTo = pointEnergy;
                    next = p.getX();
                }
            }

            if (minDistTo == Double.POSITIVE_INFINITY) {
                minDistTo = 0.0; // for bottom row
                next = w;
            }

            distTo[h][w] = energy[h][w] + minDistTo;
            nextPoint[h][w] = next;
        }
    }

    private Point[] adj(int h, int w) {
        if (h == height - 1 || width == 1) {
            return new Point[] {};
        } else if (w == 0) {
            return new Point[] { new Point(w, h + 1), new Point(w + 1, h + 1) };
        } else if (w == width - 1) {
            return new Point[] { new Point(w - 1, h + 1), new Point(w, h + 1) };
        } else {
            return new Point[] { new Point(w - 1, h + 1), new Point(w, h + 1), new Point(w + 1, h + 1) };
        }
    }

    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam) {
        if (!inverted) invert();
        generalRemoveSeam(seam);
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam) {
        if (inverted) invert();
        generalRemoveSeam(seam);
    }

    private void generalRemoveSeam(int[] seam) {
        verifyRemoveSeam(seam);
        int previousPoint = -1;
        ArrayList<Point> pointsToRecalculate = new ArrayList<Point>();

        for (int i = 0; i < height; i++) {
            // validate point
            verifySeamPoint(seam[i], previousPoint);

            int index = seam[i];
            Color[] pixelRow = pixels[i];
            double[] energyRow = energy[i];

            System.arraycopy(pixelRow, index + 1, pixelRow, index, width - index - 1);
            System.arraycopy(energyRow, index + 1, energyRow, index, width - index - 1);

            // Horizontal points
            if (index != 0) {
                pointsToRecalculate.add(new Point(index - 1, i));
            }
            if (index != width - 1) {
                pointsToRecalculate.add(new Point(index, i));
            }

            // Vertical points
            if (i > 0) {
                if (seam[i - 1] < seam[i]) {
                    pointsToRecalculate.add(new Point(index - 1, i - 1));
                } else if (seam[i - 1] > seam[i]) {
                    pointsToRecalculate.add(new Point(index, i - 1));
                }
            }

            if (i < height - 1) {
                if (seam[i] < seam[i + 1]) {
                    pointsToRecalculate.add(new Point(index, i + 1));
                } else if (seam[i] > seam[i + 1]) {
                    pointsToRecalculate.add((new Point(index - 1, i + 1)));
                }
            }

            previousPoint = index;
        }
        width--;

        for (Point p : pointsToRecalculate) {
            verifyPoint(p.getX(), p.getY());
            energy[p.getY()][p.getX()] = calculateEnergy(p.getX(), p.getY());
        }
    }

    private void invert() {
        Color[][] pixelsClone = new Color[width][height];
        double[][] energyClone = new double[width][height];

        for (int h = 0; h < height; h++) {
            for (int w = 0; w < width; w++) {
                pixelsClone[w][h] = pixels[h][w];
                energyClone[w][h] = energy[h][w];
            }
        }

        int hold = width;
        width = height;
        height = hold;
        inverted = !inverted;

        pixels = pixelsClone;
        energy = energyClone;
    }

    private double calculateEnergy(int x, int y) {
        if (x == 0 || x == width - 1 || y == 0 || y == height - 1) {
            return 1000.0;
        } else {
            Color left = pixels[y][x - 1];
            Color right = pixels[y][x + 1];
            Color above = pixels[y - 1][x];
            Color below = pixels[y + 1][x];

            double energyX = getEnergyGradient(left, right);
            double energyY = getEnergyGradient(above, below);

            return Math.sqrt(energyX + energyY);
        }
    }

    private double getEnergyGradient(Color lhs, Color rhs) {
        double red = (lhs.getRed() - rhs.getRed()) * (lhs.getRed() - rhs.getRed());
        double blue = (lhs.getBlue() - rhs.getBlue()) * (lhs.getBlue() - rhs.getBlue());
        double green = (lhs.getGreen() - rhs.getGreen()) * (lhs.getGreen() - rhs.getGreen());
        return red + blue + green;
    }

    private void verifyPoint(int x, int y) {
        if (x < 0 || y < 0 || x > width - 1 || y > height - 1) {
            throw new IndexOutOfBoundsException("Invalid point. x:" + x + " y:" + y + ".");
        }
    }

    private void verifyRemoveSeam(int[] seam) {
        if (width <= 1) {
            throw new IllegalArgumentException("Illegal removal of seam.");
        }

        if (seam == null) {
            throw new NullPointerException("null seam.");
        }

        if (seam.length != height) {
            throw new IllegalArgumentException("Seam is not the correct height");
        }
    }

    private void verifySeamPoint(int p, int previousPoint) {
        if (p < 0 || p > width) {
            throw new IllegalArgumentException("seam value is outside Picture.");
        }

        if (previousPoint != -1 && Math.abs(previousPoint - p) > 1) {
            throw new IllegalArgumentException("two adjacent entries differ by more than 1.");
        }
    }

    private final class Point {
        private final int x;
        private final int y;

        Point(int intX, int intY) {
            this.x = intX;
            this.y = intY;
        }

        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }
    }

    public static void main(String[] args) {
        Picture p = new Picture(args[0]);
        SeamCarver sc = new SeamCarver(p);
        int[] svp;
        int[] shp;
        svp = sc.findVerticalSeam();
        int[] a = { -1, 0, 0, 0, 0, 0, 2, 1, 0, 0 };
        sc.removeVerticalSeam(a);
//
//        shp = sc.findHorizontalSeam();
//        StdOut.println(shp.length);
//        sc.removeHorizontalSeam(shp);
//
//        svp = sc.findVerticalSeam();
//        sc.removeVerticalSeam(svp);
//
//        shp = sc.findHorizontalSeam();
//        sc.removeHorizontalSeam(shp);
//
        StdOut.println(sc.picture());
//        StdOut.println(sc.width());
//        StdOut.println(sc.height());
//        StdOut.println(sc.energy(0, 0));
    }
}
